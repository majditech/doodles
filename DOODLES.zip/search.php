﻿<body style="text-align:center;">
<?php

//THIS CODE CREATED BY MAJDI AWAD FOR EDUCATIONAL 

// CONNECT TO THE DB

$conn = new mysqli('localhost', 'root', '', 'google');

// CHECK IF I HAVE CONNECTED TO DB

if ($conn->connect_error) {

	echo "Was not able to coonect to DB";
	
	}
	
// COLLECT THE ENTERED DATE BY USER

$year = $_POST['year'];
$month = $_POST['month'];
$day = $_POST['day'];

// USING SQL TO FIND THE DATA WITH THE SAME DATE

$sql = mysqli_query($conn, "SELECT * FROM doodles WHERE year = '$year' AND month = '$month' AND day = '$day'");

//CHECK IF I HAVE GOT ANY RESULT FOR THE QUERY
if($sql->num_rows) {
// IF I GOT A RESULT, WI WILL START A WHILE LOOP AND FETCH THE OBJECT
while($r = $sql->fetch_object()) {
?>

<h1><?php echo $r->title; ?></h1>
<h3>
<?php 
echo $r->year;
echo "/";
echo $r->month;
echo "/";
echo $r->day;
?>
</h3>
<img src="<?php echo $r->url; ?>">
<?php
}} // CLOSE THE LOOP THEN THE IF
?>
</body>
